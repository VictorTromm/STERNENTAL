import pygame
import sys
import random

# Função para exibir a tela inicial
def exibir_tela_inicial():
    pygame.init()

    # Configurações da tela
    largura_tela, altura_tela = 1000, 750
    tela = pygame.display.set_mode((largura_tela, altura_tela))
    pygame.display.set_caption("Sternental - Tela Inicial")

    # Carrega imagem de fundo e redimensiona para caber na tela
    fundo = pygame.image.load("imagens/inicio.png").convert_alpha()
    fundo = pygame.transform.scale(fundo, (largura_tela, altura_tela))  # Ajusta o tamanho para cobrir toda a tela
    
    # Carrega e redimensiona as outras imagens
    logo = pygame.image.load("imagens/logo.png").convert_alpha()
    botao_jogar = pygame.image.load("imagens/jogar.png").convert_alpha()
    botao_sair = pygame.image.load("imagens/sair.png").convert_alpha()

    # Redimensiona as imagens dos botões, se necessário
    logo = pygame.transform.scale(logo, (500, 375))  # Exemplo de redimensionamento
    botao_jogar = pygame.transform.scale(botao_jogar, (200, 150))  # Exemplo de redimensionamento
    botao_sair = pygame.transform.scale(botao_sair, (200, 150))  # Exemplo de redimensionamento

    # Calcula posições
    logo_rect = logo.get_rect(center=(largura_tela // 2, altura_tela // 6))
    botao_jogar_rect = botao_jogar.get_rect(center=(largura_tela // 2, altura_tela - 200))
    botao_sair_rect = botao_sair.get_rect(center=(largura_tela // 2, altura_tela - 100))

    # Loop principal da tela inicial
    while True:
        tela.blit(fundo, (0, 0))  # Exibe o fundo redimensionado
        tela.blit(logo, logo_rect.topleft)
        tela.blit(botao_jogar, botao_jogar_rect.topleft)
        tela.blit(botao_sair, botao_sair_rect.topleft)

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:  # Clique esquerdo
                if botao_jogar_rect.collidepoint(evento.pos):
                    return "jogar"
                elif botao_sair_rect.collidepoint(evento.pos):
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()

# Função para o jogo
def iniciar_jogo():
    pygame.init()

    # Configurações do jogo
    largura_tela, altura_tela = 1000, 750
    tela = pygame.display.set_mode((largura_tela, altura_tela))
    pygame.display.set_caption("Sternental")

    # Carrega o fundo do jogo (grama)
    fundo = pygame.image.load("imagens/grama.png").convert_alpha()
    fundo = pygame.transform.scale(fundo, (largura_tela, altura_tela))

    # Carrega a imagem das árvores
    arvore_img = pygame.image.load("imagens/mogno.png").convert_alpha()
    arvore_img = pygame.transform.scale(arvore_img, (69, 99))  # Redimensiona a árvore

    # Carrega as imagens das skins
    skin1 = pygame.image.load("imagens/skin1.png").convert_alpha()
    skin2 = pygame.image.load("imagens/skin2.png").convert_alpha()
    skin3 = pygame.image.load("imagens/skin3.png").convert_alpha()
    skinL1 = pygame.image.load("imagens/skinL1.png").convert_alpha()
    skinL2 = pygame.image.load("imagens/skinL2.png").convert_alpha()
    skinL3 = pygame.image.load("imagens/skinL3.png").convert_alpha()

    largura_boneco = 42  # Largura do boneco
    altura_boneco = 63   # Altura do boneco

    # Redimensionar as skins com largura e altura diferentes
    skins_direita = [pygame.transform.scale(skin, (largura_boneco, altura_boneco)) for skin in [skin1, skin2, skin3]]
    skins_esquerda = [pygame.transform.scale(skin, (largura_boneco, altura_boneco)) for skin in [skinL1, skinL2, skinL3]]

    # Posições iniciais do personagem
    pos_x, pos_y = largura_tela // 2, altura_tela // 2
    personagem = skins_direita[0]  # Começa com a skin1
    personagem_rect = personagem.get_rect(center=(pos_x, pos_y))

    # Variáveis de controle
    velocidade = 5  # Velocidade de movimentação do personagem
    direcao = "parado"  # Direção inicial
    andando = False

    # Variáveis de animação
    indice_skin = 0
    tempo_animacao = 0

    # Criar algumas árvores em posições aleatórias
    num_arvores = 5  # Número de árvores no jogo
    arvores = []
    for _ in range(num_arvores):
        x_arvore = random.randint(0, largura_tela - 69)  # Garantir que a árvore caiba na tela
        y_arvore = random.randint(0, altura_tela - 99)  # Garantir que a árvore caiba na tela
        arvore_rect = arvore_img.get_rect(topleft=(x_arvore, y_arvore))
        arvores.append(arvore_rect)

    # Loop principal do jogo
    rodando = True
    while rodando:
        tela.blit(fundo, (0, 0))  # Exibe o fundo

        andando = False  # Reinicia o status de movimento

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False

            # Movimentação do personagem
            teclas = pygame.key.get_pressed()
            if teclas[pygame.K_w]:
                pos_y -= velocidade
                andando = True
            if teclas[pygame.K_s]:
                pos_y += velocidade
                andando = True
            if teclas[pygame.K_a]:
                pos_x -= velocidade
                andando = True
                if direcao != "esquerda":
                    direcao = "esquerda"
            if teclas[pygame.K_d]:
                pos_x += velocidade
                andando = True
                if direcao != "direita":
                    direcao = "direita"

            # Limitar o personagem dentro da tela
            pos_x = max(0, min(pos_x, largura_tela - largura_boneco))
            pos_y = max(0, min(pos_y, altura_tela - altura_boneco))

            # Atualiza a animação apenas se estiver andando
            if andando:
                if pygame.time.get_ticks() - tempo_animacao > 150:  # Troca a skin a cada 150 ms
                    tempo_animacao = pygame.time.get_ticks()
                    indice_skin = (indice_skin + 1) % 3  # Alterna entre 0, 1 e 2
            else:
                indice_skin = 0  # Volta para skin1 quando parado

            # Define a skin com base na direção
            if direcao == "direita" and andando:
                personagem = skins_direita[indice_skin]
            elif direcao == "esquerda" and andando:
                personagem = skins_esquerda[indice_skin]
            else:
                # Padrão (parado, olhando na direção atual)
                personagem = skins_direita[0] if direcao == "direita" else skins_esquerda[0]

        # Verificar colisão com as árvores
        personagem_rect.topleft = (pos_x, pos_y)
        for arvore in arvores:
            if personagem_rect.colliderect(arvore):
                # Se houver colisão, o personagem não pode mais se mover para aquela direção
                if teclas[pygame.K_w]:
                    pos_y += velocidade  # Impede movimento para cima
                if teclas[pygame.K_s]:
                    pos_y -= velocidade  # Impede movimento para baixo
                if teclas[pygame.K_a]:
                    pos_x += velocidade  # Impede movimento para a esquerda
                if teclas[pygame.K_d]:
                    pos_x -= velocidade  # Impede movimento para a direita

        # Desenha as árvores
        for arvore in arvores:
            tela.blit(arvore_img, arvore.topleft)

        # Desenha o personagem
        tela.blit(personagem, personagem_rect.topleft)

        pygame.display.flip()  # Atualiza a tela

    pygame.quit()
    sys.exit()

# Função principal
def main():
    resultado = exibir_tela_inicial()
    if resultado == "jogar":
        iniciar_jogo()

if __name__ == "__main__":
    main()
