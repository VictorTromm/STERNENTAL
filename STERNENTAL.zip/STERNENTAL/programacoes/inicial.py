import pygame
import sys

def exibir_tela_inicial():
    # Inicializa o Pygame
    pygame.init()
    
    # Configurações da tela
    largura_tela, altura_tela = 1000, 750
    tela = pygame.display.set_mode((largura_tela, altura_tela))
    pygame.display.set_caption("Sternental - Tela Inicial")
    
    # Carrega imagem de fundo e redimensiona para caber na tela
    fundo = pygame.image.load("imagens/inicio.png").convert_alpha()
    fundo = pygame.transform.scale(fundo, (largura_tela, altura_tela))  # Ajusta o tamanho para cobrir toda a tela
    
    # Carrega e redimensiona as outras imagens
    logo = pygame.image.load("imagens/logo.png").convert_alpha()
    botao_jogar = pygame.image.load("imagens/jogar.png").convert_alpha()
    botao_sair = pygame.image.load("imagens/sair.png").convert_alpha()

    # Redimensiona as imagens dos botões, se necessário
    logo = pygame.transform.scale(logo, (500, 375))  # Exemplo de redimensionamento
    botao_jogar = pygame.transform.scale(botao_jogar, (200, 150))  # Exemplo de redimensionamento
    botao_sair = pygame.transform.scale(botao_sair, (200, 150))  # Exemplo de redimensionamento

    # Calcula posições
    logo_rect = logo.get_rect(center=(largura_tela // 2, altura_tela // 6))
    botao_jogar_rect = botao_jogar.get_rect(center=(largura_tela // 2, altura_tela - 200))
    botao_sair_rect = botao_sair.get_rect(center=(largura_tela // 2, altura_tela - 100))
    
    # Loop principal da tela inicial
    while True:
        tela.blit(fundo, (0, 0))  # Exibe o fundo redimensionado
        tela.blit(logo, logo_rect.topleft)
        tela.blit(botao_jogar, botao_jogar_rect.topleft)
        tela.blit(botao_sair, botao_sair_rect.topleft)
        
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:  # Clique esquerdo
                if botao_jogar_rect.collidepoint(evento.pos):
                    return "jogar"
                elif botao_sair_rect.collidepoint(evento.pos):
                    pygame.quit()
                    sys.exit()
        
        pygame.display.flip()

# Chama a função para exibir a tela inicial
exibir_tela_inicial()
